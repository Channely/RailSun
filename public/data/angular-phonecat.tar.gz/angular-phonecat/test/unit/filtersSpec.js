'use strict';

/* jasmine specs for filters go here */

describe('filter', function() {

});
